# Frozen-RTL fault and safety results

Target: b33a9227ac187f791a3733b94ac4e32879b10414, full variant. The runner archives the exact revision, then applies mutations to the temporary simulation copy. The owner-side registry records three positive jobs with one compound check each and five mutation replays.

| Check | Result and scope |
| --- | --- |
| Top-level SPI fault and recovery | PASS. A partial SPI data byte did not commit at core/16. A one-byte entry word with a valid CRC was rejected. Skipping entry-valid checking tripped TRUNCATED_ENTRY_INVALID. Bad CRC won over pin conflict. WAIT timed out and returned pins to safe values. FIFO overflow and underflow flags latched and cleared, a protected RUN write was blocked, and reset during RUN allowed reload. |
| CRC priority mutation | Caught by CRC_BEFORE_PIN. Disabling the CRC comparison exposed the later pin conflict. |
| Protected-write mutation | Caught by RUN_WRITE_BLOCKED. Removing the HALT condition let the test write the pin setting during RUN. |
| Seeded lifecycle | PASS. Three seeds and 48 commands per seed. A prefix reached HALT, READY, RUN and FAULT, followed by seeded command sequences. The illegal-ENABLE mutation failed LIFECYCLE_ORACLE. |
| Seeded validation | PASS. Seed 53273, 24 cases spanning legal and illegal output-pin settings and good/bad CRC. A CRC-bypass replay failed VALIDATION_ORACLE. |
| Registered pin guard and FIFO | B(16), Yosys SAT. Proved open-drain drive-low, safe registered enables and dedicated idle values outside RUN, and release-only arbitration override using a second guard with arbitration loss held inactive. The depth-four FIFO matched an independent shift-queue reference for level and head data, including simultaneous requests. |
| Arbitration detection and release | B(16). Proved the four-clock pad-to-OE bound in continuous RUN with threshold three, fixed legal SDA/SCL pins and release intent. A separate SAT witness reached a qualifying request and latched flag. |
| HALT-only writes and RX read acknowledgement | Config-block SAT over two steps with arbitrary starting state. Protected write strobes require HALT, and RX pop is qualified by reset, completed host acknowledgement and exact address. |
| Monitor non-intrusion | The elaborated netlist shows that the monitor’s outputs enter only the config bank and reach only its bus_rdata output. The host uses that net as SPI read payload. Existing directed RTL evidence checks functional outputs. |

[Owner job registry and expected results](check_registry.csv) · [Seven-property results](property_results.csv) · [Positive log](faults_positive.log) · [CRC mutation](faults_mutant_crc.log) · [Write mutation](faults_mutant_write.log) · [Truncated-entry mutation](faults_mutant_truncated.log) · [Bounded proof log](formal.log)

## Proof and campaign limits

The seeds and bounds describe the executed scope. The lifecycle oracle observes SPI-visible stable states after commands, and the validation campaign exercises the output-pin bank and CRC precedence. Additional combinations remain recorded in the traceability files. The monitor check concerns on-chip dependencies. External host behavior can use the reported results. Formal analysis uses a digital clock model and bounded sequences.

[Lifecycle mutation](faults_mutant_lifecycle.log) · [Validation mutation](faults_mutant_validation.log) · [Arbitration proof and witness](arbitration_formal.log) · [Config proof](config_formal.log) · [Monitor cone](monitor_cone.log)

The additional D-013 B(2) check verifies OSR count and empty status after either reset or ENABLE for legal thresholds. [OSR proof](osr_formal.log)

In WSL run the following from an environment with Git, Icarus, Python 3 and venv. Use the same script with a final argument of formal for the Yosys SAT run. The runner installs cocotb 2.0.1 and the formal run used YoWASP Yosys 0.71.

```sh
project=/mnt/c/vivado_verilog_proj/JANE_STREET/01_CURRENT
bash "$project/Astra_owner_review/Verification_H4_H5/run_owner_checks.sh" "$project" faults
bash "$project/Astra_owner_review/Verification_H4_H5/run_owner_checks.sh" "$project" formal
```
