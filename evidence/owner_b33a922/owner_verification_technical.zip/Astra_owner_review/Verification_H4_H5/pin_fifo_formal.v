module pin_fifo_formal (
    input clk, rst_n, clr, push, pop,
    input [7:0] din,
    input [2:0] state,
    input [139:0] pin_cfg,
    input [19:0] out_val, oe_val,
    input [3:0] lut_out,
    input arb_en, arb_lost,
    input [4:0] arb_sda, arb_scl
);
    wire [7:0] uio_out, uio_oe, dout;
    wire [7:0] unguarded_out, unguarded_oe;
    wire [6:0] uo;
    wire [6:0] unguarded_uo;
    wire [2:0] level;
    wire full, empty;
    reg valid = 0;
    reg [31:0] reference_queue;
    reg [2:0] reference_level;
    wire reference_pop = pop && reference_level != 0;
    wire reference_push = push && (reference_level < 4 || reference_pop);
    wire [31:0] after_pop = reference_pop ? reference_queue >> 8 : reference_queue;
    wire [2:0] after_pop_level = reference_level - {2'b00, reference_pop};
    wire [4:0] insertion = {after_pop_level[1:0], 3'b000};
    pvm_pin_guard guard_dut(clk, rst_n, state, pin_cfg, out_val, oe_val, lut_out,
        arb_en, arb_lost, arb_sda, arb_scl, uo, uio_out, uio_oe, , );
    pvm_pin_guard no_override(clk, rst_n, state, pin_cfg, out_val, oe_val, lut_out,
        arb_en, 1'b0, arb_sda, arb_scl, unguarded_uo, unguarded_out, unguarded_oe, , );
    pvm_fifo fifo_dut(clk, rst_n, clr, push, din, pop, dout, full, empty, level, , );
    always @(posedge clk) begin
        valid <= 1;
        if (!valid) assume(!rst_n);
        if (!rst_n || clr) begin
            reference_queue <= 0;
            reference_level <= 0;
        end else begin
            reference_queue <= reference_push
                ? ((after_pop & ~(32'hff << insertion)) | ({24'd0, din} << insertion))
                : after_pop;
            reference_level <= after_pop_level + {2'b00, reference_push};
        end
        if (valid) begin
            assert(level <= 4);
            assert(level == reference_level);
            assert(dout == (reference_level == 0 ? 8'd0 : reference_queue[7:0]));
            assert(full == (level == 4));
            assert(empty == (level == 0));
            assert(uio_out == unguarded_out && uo == unguarded_uo);
            assert((uio_oe & ~unguarded_oe) == 0);
            if (empty) assert(dout == 0);
            if (!$past(rst_n) || $past(state) != 3) assert(uio_oe == 0);
            if (!$past(rst_n) || $past(clr)) assert(level == 0);
            else if ($past(pop && !empty) && !$past(push)) assert(level == $past(level) - 1);
            else if (!$past(pop) && !$past(push)) assert(level == $past(level));
        end
    end
    genvar i;
    generate for (i = 0; i < 8; i = i + 1) begin
        localparam [4:0] PIN = i + 12;
        always @(posedge clk) if (valid) begin
            if ($past(pin_cfg[7*PIN+3+:2]) == 2) assert(!(uio_oe[i] && uio_out[i]));
            if ($past(arb_en && arb_lost && (arb_sda == PIN || arb_scl == PIN)))
                assert(!uio_oe[i]);
            else
                assert(uio_oe[i] == unguarded_oe[i]);
        end
    end endgenerate
    generate for (i = 0; i < 7; i = i + 1) begin
        always @(posedge clk) if (valid) begin
            if (!$past(rst_n))
                assert(uo[i] == 0);
            else if ($past(state) != 3)
                assert(uo[i] == $past(pin_cfg[7*(i+5)+5]));
        end
    end endgenerate
endmodule
