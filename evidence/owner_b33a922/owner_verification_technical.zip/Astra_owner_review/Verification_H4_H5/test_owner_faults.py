"""External host/pin checks on the frozen full variant."""

from binascii import crc_hqx
from random import Random

import cocotb
from cocotb.clock import Clock

from test import SpiHost


class PartialHost(SpiHost):
    async def abort(self, prefix, value, bits):
        await self.wait_cycles(8)
        for bit in [b >> i & 1 for b in prefix for i in range(7, -1, -1)] + [
            value >> i & 1 for i in range(7, 7 - bits, -1)
        ]:
            self.dut.ui_in.value = bit << 2
            await self.wait_cycles(8)
            self.dut.ui_in.value = (bit << 2) | 1
            await self.wait_cycles(8)
        self.dut.ui_in.value = 2
        await self.wait_cycles(8)


async def command(host, value):
    await host.write(0x0F00, bytes([value]))


async def install(host, writes, corrupt_crc=False):
    crc = crc_hqx(bytes(byte for _, data in writes for byte in data), 0xFFFF)
    for addr, data in writes:
        await host.write(addr, data)
    await host.write(0x0F08, (crc ^ int(corrupt_crc)).to_bytes(2, "little"))
    await command(host, 2)


async def expect_fault(host, code, check):
    status, fault, pc = await host.read(0x0F01, 3)
    assert (status & 7, fault & 15, pc) == (5, code, 0), check


@cocotb.test()
async def directed_top_level_faults(dut):
    dut.ena.value = 1
    dut.ui_in.value = 2
    dut.uio_in.value = 0
    dut.rst_n.value = 0
    cocotb.start_soon(Clock(dut.clk, 20, unit="ns").start())
    host = PartialHost(dut)
    await host.wait_cycles(5)
    dut.rst_n.value = 1
    await host.wait_cycles(5)

    await host.abort(b"\x02\x04\x05", 0x29, 7)
    assert await host.read(0x0405, 1) == b"\x00", "ABORT_NO_PARTIAL_WRITE"
    await install(host, [(0, b"\x00")])
    await expect_fault(host, 7, "TRUNCATED_ENTRY_INVALID")
    await command(host, 1)
    await install(host, [(0, b"\x00\x00"), (0x0405, b"\x11")], corrupt_crc=True)
    await expect_fault(host, 5, "CRC_BEFORE_PIN")
    await command(host, 1)
    await install(host, [(0, b"\x00\x00"), (0x0405, b"\x11")])
    await expect_fault(host, 6, "PIN_CONFLICT")
    await command(host, 1)

    await install(host, [(0, b"\x80\x20"), (0x0405, b"\x29"), (0x0110, b"\x04\x00")])
    await command(host, 3)
    await expect_fault(host, 2, "WAIT_TIMEOUT")
    assert int(dut.uio_oe.value) == 0 and int(dut.uo_out.value) & 1, "FAULT_PINS_SAFE"
    await command(host, 5)
    assert (await host.read(0x0F01, 1))[0] & 7 == 0, "CLEAR_FAULT_TO_HALT"

    for value in range(5):
        await host.write(0x0F10, bytes([value]))
    assert (await host.read(0x0F12, 1))[0] & 7 == 4, "TX_LEVEL_SATURATES"
    assert await host.read(0x0F11, 1) == b"\x00", "EMPTY_RX_DATA"
    assert (await host.read(0x0F01, 1))[0] & 0x30 == 0x30, "FIFO_STICKY_ERRORS"
    await command(host, 1)
    assert (await host.read(0x0F01, 1))[0] & 0x3F == 0, "HALT_CLEARS_FIFO_ERRORS"

    for attempt in range(2):
        await install(host, [(0, b"\x00\x00"), (0x0405, b"\x29")])
        await command(host, 3)
        assert (await host.read(0x0F01, 1))[0] & 7 == 3, "RELOADED_RUN"
        await host.write(0x0405, b"\x00")
        assert await host.read(0x0405, 1) == b"\x29", "RUN_WRITE_BLOCKED"
        if attempt == 0:
            dut.rst_n.value = 0
            await host.wait_cycles(4)
            assert int(dut.uio_oe.value) == 0 and int(dut.uo_out.value) & 127 == 0, "RESET_PINS_SAFE"
            dut.rst_n.value = 1
            await host.wait_cycles(5)
            assert (await host.read(0x0F01, 1))[0] & 7 == 0, "RESET_TO_HALT"
    dut._log.info("CHECK PASS OWNER_FAULTS (1 compound check)")


@cocotb.test()
async def seeded_lifecycle(dut):
    dut.ena.value = 1
    dut.ui_in.value = 2
    dut.uio_in.value = 0
    dut.rst_n.value = 0
    cocotb.start_soon(Clock(dut.clk, 20, unit="ns").start())
    host = PartialHost(dut)
    await host.wait_cycles(5)
    dut.rst_n.value = 1
    await host.wait_cycles(5)

    for seed in (1729, 512, 65521):
        rng = Random(seed)
        await command(host, 1)
        program = b"\x00\x00"
        await host.write(0, program)
        await host.write(0x0F08, crc_hqx(program, 0xFFFF).to_bytes(2, "little"))
        state, rejected = 0, False
        covered = set()
        for index in range(48):
            # A deliberate prefix reaches READY, RUN and CRC FAULT for every seed.
            prefix = (2, 3, 3, 1, 2, 5)
            action = prefix[index] if index < len(prefix) else rng.choice((1, 2, 3, 5, 0x81))
            await command(host, action)
            if action == 1:
                state, rejected = 0, False
            elif (state, action) == (0, 2):
                # After HALT the previous expected CRC remains, but the
                # running CRC is reset and no image bytes have been rewritten.
                state = 2 if index == 0 else 5
            elif (state, action) == (2, 3):
                state = 3
            elif (state, action) == (5, 5):
                state = 0
            else:
                rejected = True
            status = (await host.read(0x0F01, 1))[0]
            assert (status & 7, bool(status & 8)) == (state, rejected), (
                f"LIFECYCLE_ORACLE seed={seed} step={index} command={action:#04x} "
                f"observed={status:#04x} expected state={state} WR_REJ={rejected}"
            )
            if state != 3:
                assert int(dut.uio_oe.value) == 0, "LIFECYCLE_PINS_SAFE"
            covered.add(state)
        assert covered == {0, 2, 3, 5}
        dut._log.info("LIFECYCLE_ORACLE seed=%d commands=48 states=%s", seed, sorted(covered))
    dut._log.info("CHECK PASS OWNER_LIFECYCLE (1 compound check)")


@cocotb.test()
async def seeded_validation(dut):
    dut.ena.value = 1
    dut.ui_in.value = 2
    dut.uio_in.value = 0
    dut.rst_n.value = 0
    cocotb.start_soon(Clock(dut.clk, 20, unit="ns").start())
    host = PartialHost(dut)
    await host.wait_cycles(5)
    dut.rst_n.value = 1
    await host.wait_cycles(5)

    seed = 0xD019
    rng = Random(seed)
    cases = [(fault, i % 2 == 0) for fault in (0, 6, 7) for i in range(8)]
    rng.shuffle(cases)
    last_fault = 0
    for index, (config_fault, bad_crc) in enumerate(cases):
        await command(host, 1)
        pin = rng.randrange(5, 12)
        idle = rng.choice((0, 0x20))
        pattern = {0: 0x09, 6: 0x11, 7: 0x19}[config_fault] | idle
        # Rewrite the full output pin bank on each trial so earlier bad modes
        # cannot leak across HALT, which preserves the image.
        pins = bytearray(7)
        pins[pin - 5] = pattern
        await install(host, [(0, b"\x00\x00"), (0x0405, pins)], corrupt_crc=bad_crc)
        status, fault, pc = await host.read(0x0F01, 3)
        expected_fault = 5 if bad_crc else config_fault
        if expected_fault:
            last_fault = expected_fault
        expected = (5 if expected_fault else 2, last_fault, 0)
        observed = (status & 7, fault & 15, pc)
        assert observed == expected, (
            f"VALIDATION_ORACLE seed={seed} case={index} pin={pin} "
            f"pattern={pattern:#04x} bad_crc={bad_crc} observed={observed} expected={expected}"
        )
    dut._log.info("CHECK PASS OWNER_VALIDATION (1 compound check, seed=%d cases=%d)", seed, len(cases))
