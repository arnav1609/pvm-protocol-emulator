module arb_path_formal(input clk, rst_n, scl, sda);
    reg valid = 0;
    reg [2:0] age = 0;
    reg [2:0] previous_high = 0;
    (* keep *) reg seen_request = 0, seen_flag = 0;
    wire [7:0] uio_out, uio_oe;
    wire [19:0] intent;
    wire [1:0] sampled;
    wire arb_lost;
    wire [139:0] cfg = {42'd0, 7'h11, 7'h11, 84'd0};
    pvm_sync2 #(.W(2)) pin_sync(clk, rst_n, {scl, sda}, sampled);
    pvm_fabric fab(
        .clk(clk), .rst_n(rst_n), .run(1'b1), .enable_pulse(1'b0),
        .engine_tick(1'b0), .pin_in({6'd0, sampled, 12'd0}),
        .od_release_intent(intent), .fab_ctrl(4'd0), .fab_wr(1'b0),
        .cfg_lut(128'd0), .cfg_mode(12'd0), .cnt_reload(10'd0),
        .cnt_en(1'b0), .cnt_src(1'b0), .manch_en(1'b0),
        .arb_en(1'b1), .arb_n(4'd3), .arb_sda(5'd12), .arb_scl(5'd13),
        .clr_flags(1'b0), .evt_clr_arb(1'b0), .evt_clr_unf(1'b0), .arb_lost(arb_lost)
    );
    pvm_pin_guard guard_dut(
        .clk(clk), .rst_n(rst_n), .state(3'd3), .pin_cfg(cfg),
        .out_val(20'h01000), .oe_val(20'h03000), .lut_out(4'd0),
        .arb_en(1'b1), .arb_lost(arb_lost), .arb_sda(5'd12), .arb_scl(5'd13),
        .uio_out(uio_out), .uio_oe(uio_oe), .od_release_intent(intent)
    );
    wire request = (&previous_high) && scl && !sda;
    always @(posedge clk) begin
        valid <= 1;
        if (!valid) assume(!rst_n);
        if (!rst_n) begin
            age <= 0;
            previous_high <= 0;
            seen_request <= 0;
            seen_flag <= 0;
        end else begin
            if (age < 7) age <= age + 1'b1;
            previous_high <= {previous_high[1:0], scl};
            seen_request <= seen_request || request;
            seen_flag <= seen_flag || arb_lost;
        end
        if (age >= 5 && $past(request, 4))
            assert(arb_lost && uio_oe[1:0] == 0);
    end
endmodule
