#!/usr/bin/env bash
set -euo pipefail

repo=${1:?Pass the repository directory, or its parent 01_CURRENT, in WSL}
if [[ -d "$repo/pvm-protocol-emulator" ]]; then
    repo="$repo/pvm-protocol-emulator"
fi
kit=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
root=$(mktemp -d)
git -C "$repo" -c core.autocrlf=false archive b33a9227ac187f791a3733b94ac4e32879b10414 | tar -x -C "$root"
python3 -m venv "$root/.venv"
source "$root/.venv/bin/activate"

if [[ ${2:-} == formal ]]; then
    python -m pip -q install yowasp-yosys
    cp "$kit/pin_fifo_formal.v" "$root/"
    cd "$root"
    yowasp-yosys -V
    yowasp-yosys -p 'read_verilog -formal src/pvm_pin_guard.v src/pvm_fifo.v pin_fifo_formal.v; hierarchy -top pin_fifo_formal; proc; async2sync; chformal -lower; flatten; memory_map; opt; sat -verify -set-assumes -seq 16 -prove-asserts' | tee "$kit/formal.log"
    yowasp-yosys -Q -T -p 'read_verilog src/*.v; hierarchy -top pvm_top; proc; write_json monitor_cone.json' > "$kit/monitor_elaboration.log"
    python "$kit/check_monitor_cone.py" monitor_cone.json | tee "$kit/monitor_cone.log"
    cp "$kit/arb_path_formal.v" "$root/"
    yowasp-yosys -p 'read_verilog -formal src/pvm_sync2.v src/pvm_fabric.v src/pvm_pin_guard.v arb_path_formal.v; hierarchy -top arb_path_formal; proc; async2sync; chformal -lower; flatten; opt; sat -verify -set-assumes -seq 16 -prove-asserts; sat -set-assumes -seq 12 -set-at 12 seen_request 1 -set-at 12 seen_flag 1 -show scl,sda,arb_lost,uio_oe' | tee "$kit/arbitration_formal.log"
    grep -F 'SAT solving finished - model found' "$kit/arbitration_formal.log"
    python - <<'PY'
from pathlib import Path

path = Path("src/pvm_cfg.v")
source = path.read_text()
insertion = """
    always @* begin
        assert(!wh_write || (state == S_HALT));
        assert(!imem_wr_en || (state == S_HALT));
        assert(rx_pop == (rst_n && bus_rack && bus_addr == 16'h0f11));
    end
"""
assert source.count("endmodule") == 1
path.write_text(source.replace("endmodule", insertion + "endmodule"))

path = Path("src/pvm_engine.v")
source = path.read_text()
insertion = """
    reg owner_checked = 0;
    always @(posedge clk) begin
        owner_checked <= 1;
        if (owner_checked && $past(!rst_n || enable_pulse)) begin
            assert(osr_cnt_q == 16);
            if (pull_limit <= 16) assert(osr_empty);
        end
    end
"""
assert source.count("endmodule") == 1
path.write_text(source.replace("endmodule", insertion + "endmodule"))
PY
    yowasp-yosys -p 'read_verilog -formal src/pvm_cfg.v src/pvm_crc16.v; hierarchy -top pvm_cfg; proc; chformal -lower; flatten; memory_map; opt; sat -verify -seq 2 -prove-asserts' | tee "$kit/config_formal.log"
    yowasp-yosys -p 'read_verilog -formal src/pvm_engine.v src/pvm_tick.v src/pvm_presc.v; hierarchy -check -top pvm_engine; proc; async2sync; chformal -lower; flatten; opt; sat -verify -seq 2 -prove-asserts' | tee "$kit/osr_formal.log"
    exit
fi

python -m pip -q install cocotb==2.0.1
cp "$kit/test_owner_faults.py" "$root/test/"
cd "$root/test"
export PYTHONPATH=..
make COCOTB_TEST_MODULES=test_owner_faults 2>&1 | tee "$kit/faults_positive.log"
grep -F 'CHECK PASS OWNER_FAULTS (1 compound check)' "$kit/faults_positive.log"
grep -F 'CHECK PASS OWNER_LIFECYCLE (1 compound check)' "$kit/faults_positive.log"
grep -F 'CHECK PASS OWNER_VALIDATION (1 compound check,' "$kit/faults_positive.log"

for mutant in crc write lifecycle validation truncated; do
    git -C "$repo" -c core.autocrlf=false show b33a922:src/pvm_cfg.v > ../src/pvm_cfg.v
    python - "$mutant" <<'PY'
from pathlib import Path
import sys

source = Path("../src/pvm_cfg.v")
old, new = {
    "crc": ("V_CRC: if (crc_calc != crc_expect_q)", "V_CRC: if (1'b0)"),
    "write": ("wh_addr && (state == S_HALT);", "wh_addr;"),
    "lifecycle": ("(bus_wdata == C_ENABLE && state == S_READY)",
                  "(bus_wdata == C_ENABLE)"),
    "validation": ("V_CRC: if (crc_calc != crc_expect_q)", "V_CRC: if (1'b0)"),
    "truncated": ("(wrap_bottom > wrap_top) || !imem_entry_valid",
                  "(wrap_bottom > wrap_top)"),
}[sys.argv[1]]
text = source.read_text()
assert text.count(old) == 1
source.write_text(text.replace(old, new))
PY
    case "$mutant" in
        crc) expected=CRC_BEFORE_PIN; filter=directed_top_level_faults ;;
        write) expected=RUN_WRITE_BLOCKED; filter=directed_top_level_faults ;;
        lifecycle) expected=LIFECYCLE_ORACLE; filter=seeded_lifecycle ;;
        validation) expected=VALIDATION_ORACLE; filter=seeded_validation ;;
        truncated) expected=TRUNCATED_ENTRY_INVALID; filter=directed_top_level_faults ;;
    esac
    if make COCOTB_TEST_MODULES=test_owner_faults COCOTB_TEST_FILTER="$filter" 2>&1 | tee "$kit/faults_mutant_$mutant.log"; then
        echo "Mutant $mutant survived" >&2
        exit 1
    fi
    grep -F "AssertionError: $expected" "$kit/faults_mutant_$mutant.log"
done
