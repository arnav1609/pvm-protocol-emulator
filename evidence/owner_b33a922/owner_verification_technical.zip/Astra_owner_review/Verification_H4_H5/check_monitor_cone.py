"""Verify the post-elaboration monitor dependency boundary."""

import json
from pathlib import Path
import sys


def ports(module):
    return {name: set(port["bits"]) for name, port in module["ports"].items()}


modules = json.loads(Path(sys.argv[1]).read_text())["modules"]
cfg = modules["pvm_cfg"]
top = modules["pvm_top"]
monitor = top["cells"]["monitor"]
bank = top["cells"]["config_bank"]
monitor_outputs = [name for name, direction in monitor["port_directions"].items()
                   if direction == "output"]
assert monitor_outputs
assert all(monitor["connections"][name] == bank["connections"][name]
           for name in monitor_outputs)
monitor_bits = {bit for name in monitor_outputs for bit in monitor["connections"][name]}
for name, cell in top["cells"].items():
    for port, bits in cell["connections"].items():
        if cell["port_directions"][port] == "input" and monitor_bits.intersection(bits):
            assert name == "config_bank" and port in monitor_outputs, (name, port)
assert not set.union(*ports(top).values()).intersection(monitor_bits)

cfg_ports = ports(cfg)
affected = set.union(*(cfg_ports[name] for name in monitor_outputs))
while True:
    downstream = affected.copy()
    for cell in cfg["cells"].values():
        inputs = {bit for port, bits in cell["connections"].items()
                  if cell["port_directions"][port] == "input" for bit in bits}
        if affected.intersection(inputs):
            downstream.update(bit for port, bits in cell["connections"].items()
                              if cell["port_directions"][port] == "output" for bit in bits)
    if affected == downstream:
        break
    affected = downstream
outputs = {name for name, port in cfg["ports"].items()
           if port["direction"] == "output" and affected.intersection(cfg_ports[name])}
assert outputs == {"bus_rdata"}, outputs
print("PASS MONITOR_CONE: monitor outputs enter config_bank and reach only bus_rdata")
