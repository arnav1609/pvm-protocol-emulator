#!/usr/bin/env bash
set -euo pipefail

bundle=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
repo=$(cd "${1:?Pass the path to the checked-out v1.0 candidate}" && pwd)
out=$(mkdir -p "${2:-./pvm-gate-replay}" && cd "${2:-./pvm-gate-replay}" && pwd)
commit=752ebb97824cfd1161581497c22d3c171c4c6ca9
git -C "$repo" diff --exit-code "$commit" -- src/ info.yaml tb_rtl/ test/ tools/
git -C "$repo" diff --cached --exit-code "$commit" -- src/ info.yaml tb_rtl/ test/ tools/

pdk_root="$out/pdk"
pdk="$pdk_root/ihp-sg13cmos5l/libs.ref"
pdk_rev=89d42ee6d2fd9b50b86a1aada6fee6673c3e6008
pdk_url="https://raw.githubusercontent.com/IHP-GmbH/IHP-Open-PDK/$pdk_rev/ihp-sg13cmos5l/libs.ref"
io=sg13cmos5l_io/verilog/sg13cmos5l_io.v
udp=sg13cmos5l_stdcell/verilog/sg13cmos5l_udp.v
std=sg13cmos5l_stdcell/verilog/sg13cmos5l_stdcell.v
netlist="$bundle/tt_submission/tt_um_arnav1609_pvm.v"

for model in "$io" "$udp" "$std"; do
    mkdir -p "$pdk/$(dirname "$model")"
    curl --fail --silent --show-error --location --retry 3 \
        "$pdk_url/$model" -o "$pdk/$model"
done

sha256sum -c <<SUMS | tee "$out/hashes.log"
e7f061e6bbaab1f222dd3fd3f4925da9fcf3625588f4aaf6cabbe7cd1f9f17e7  $netlist
ae986803821a9d6c3af9c221c33c3aa58ca23c283d3ad93ed4b3a2c45d6ccb4d  $pdk/$io
5491a3edf7468792b5222e7abe057e0583a407c01b2086d4fd44a55b6cf88055  $pdk/$udp
485945f1b167daa68354548f46c95bdbff7d931516fc5b4edd47f2e2cd555735  $pdk/$std
SUMS

for protocol in UART SPI I2C; do
    iverilog -g2005 -DFUNCTIONAL -DSIM -D"PVM_PROTOCOL_$protocol" \
        -s tb_protocols -o "$out/$protocol.vvp" \
        "$pdk/$io" "$pdk/$udp" "$pdk/$std" "$netlist" "$repo/tb_rtl/tb_protocols.v"
    vvp -n "$out/$protocol.vvp" | tee "$out/$protocol.log"
    grep -Fqx 'RESULT : PASS' "$out/$protocol.log"
done

cp "$netlist" "$repo/test/gate_level_netlist.v"
(
    cd "$repo/test"
    GATES=yes PDK=ihp-sg13cmos5l PDK_ROOT="$pdk_root" PYTHONPATH=.. \
        PVM_DMX_IMAGE="$repo/tools/examples/dmx512_tx.image.json" \
        PVM_DMX_CAPTURE="$out/dmx512" \
        make COCOTB_TEST_MODULES=capture_dmx512 | tee "$out/dmx512.log"
    python -m cocotb_tools.check_results results.xml
    cp results.xml "$out/dmx512.xml"
)

for packet_run in 1 2; do
    cmp "$out/dmx512/run_${packet_run}_p5.csv" \
        "$repo/evidence/dmx512_tx/positive/run_${packet_run}_p5.csv"
done
printf '%s\n' 'PASS: UART, SPI and I2C pin checks. Both DMX512 captures match RTL.'
