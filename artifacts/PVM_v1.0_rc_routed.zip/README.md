# PVM v1.0 candidate routed build

Source commit `752ebb97824cfd1161581497c22d3c171c4c6ca9` was built at
50 MHz with the 8×4 IHP SG13CMOS5L footprint. The RTL and tapeout
inputs match `rtl-freeze` at
`b33a9227ac187f791a3733b94ac4e32879b10414`.

[Exact source](https://github.com/arnav1609/pvm-protocol-emulator/tree/752ebb97824cfd1161581497c22d3c171c4c6ca9) · [Release review](https://github.com/arnav1609/pvm-protocol-emulator/tree/codex/pvm-v1.0-rc) · [Tiny Tapeout run](https://github.com/arnav1609/pvm-protocol-emulator/actions/runs/45050926472)

## Files

- `tt_submission/` contains the GDS, OAS, routed Verilog netlist,
  LEF, nominal SPEF, build input records and summary metrics.
- `timing/` contains the post-route slack and path reports, SDC and
  SDFs for all three corners.
- `comparison/` contains all four variants' raw metrics and source
  metadata plus the A/B/C/D comparison.
- `precheck/` contains the Tiny Tapeout XML verdicts, DRC reports and
  parsed case summary.
- `gate_replay/` contains the CI smoke verdict, local pin-test logs
  and the two DMX512 capture CSVs.
- `dmx512/` contains the accepted 29-word assembly, config, exact
  committed image and hex listing.

Use `sha256sum -c SHA256SUMS.txt` in this directory to verify the
files. The netlist SHA-256 is
`e7f061e6bbaab1f222dd3fd3f4925da9fcf3625588f4aaf6cabbe7cd1f9f17e7`.

## Gate-level replay

Use Git, make, curl, Icarus Verilog 13.0 (`iverilog` and `vvp` on
PATH) and Python 3.12. Unpack this ZIP and run from its directory.

```sh
git clone --branch codex/pvm-v1.0-rc https://github.com/arnav1609/pvm-protocol-emulator.git
git -C pvm-protocol-emulator checkout --detach 752ebb97824cfd1161581497c22d3c171c4c6ca9
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r pvm-protocol-emulator/test/requirements.txt
bash replay.sh pvm-protocol-emulator pvm-gate-replay
```

The script downloads and verifies three pinned IHP functional cell
models, runs the UART/SPI/I²C pin benches, and loads the exact DMX512
image through SPI in a gate-level simulation. It checks both DMX
captures against the frozen RTL captures. This replay uses zero-delay
functional models. The package provides SDF separately.

To regenerate the DMX512 image, run from the repository root.

```sh
python -m tools.pvm_asm tools/examples/dmx512_tx.pvm /tmp/pvm-dmx512.hex
python -m tools.pvm_image tools/examples/dmx512_tx.pvm /tmp/pvm-dmx512.json \
  --config tools/examples/dmx512_tx.json
cmp /tmp/pvm-dmx512.json tools/examples/dmx512_tx.image.json
```
